**Hong Kong Television add-on for KODI (former XBMC)**

Channel supported (in alphabetical order):
- AppleDaily Action-News https://hk.appledaily.com/
- CableTV News Channel http://www.cabletv.com.hk/
- HKOpenTV Channel 77 http://www.hkopentv.com/
- NowTV 331 and 332 http://nowtv.now.com/
- RTHK Channel 31 and 32 https://www.rthk.hk/tv
- ViuTV Channel 99 https://viu.tv/

**Please subscribe to their service to support their work**

Tutorial of installing KODI on Raspberry-Pi:
- https://10to7.xyz/raspberry-pi-set-up/

Tutorial of installing add-on on KODI:
- https://10to7.xyz/install-zipped-add-on-on-kodi-former-xbmc/