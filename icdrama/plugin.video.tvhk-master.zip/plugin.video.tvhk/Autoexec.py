import xbmc
xbmc.executebuiltin('RunScript(plugin.video.tvhk)')
